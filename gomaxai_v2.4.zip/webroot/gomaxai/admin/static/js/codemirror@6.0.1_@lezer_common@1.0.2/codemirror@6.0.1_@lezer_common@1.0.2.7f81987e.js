
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{h as r,d as o,k as a}from"../@codemirror_view@6.10.1/@codemirror_view@6.10.1.3e2a74d9.js";import{u as m,v as s}from"../@codemirror_language@6.6.0/@codemirror_language@6.6.0.b1412095.js";import{h as e,d as i,a as c}from"../@codemirror_commands@6.2.3/@codemirror_commands@6.2.3.6d72013c.js";const d=(()=>[r(),e(),o(),m(s,{fallback:!0}),a.of([...i,...c])])();export{d as m};
