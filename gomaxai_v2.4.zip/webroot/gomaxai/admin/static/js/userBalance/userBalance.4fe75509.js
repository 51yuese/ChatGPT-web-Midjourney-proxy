
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{i as a}from"../main-43ee7a9a.js";const e={upgradeBalance:e=>a.post("balance/upgradeBalance",e),queryUserAccountLog:e=>a.get("balance/accountLog",{params:e})};export{e as a};
