
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{i as t}from"../main-43ee7a9a.js";const e={queryAllConfig:()=>t.get("config/queryAll"),queryGptKeys:()=>t.get("config/queryGptKeys"),setGptKeys:e=>t.post("config/setGptKeys",e),queryConfig:e=>t.post("config/query",e),copyright:()=>t.get("config/copyright"),setConfig:e=>t.post("config/set",e)};export{e as a};
