
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{c as a,a as r}from"../main-43ee7a9a.js";import{a as s}from"../config/config.d1f7645a.js";import{b as t}from"../vue-router@4.1.6_vue@3.2.47/vue-router@4.1.6_vue@3.2.47.0dcda182.js";import{d as o,m as e,o as i,c,K as n,_ as p,$ as u,a as m}from"../@vue_runtime-core@3.2.47/@vue_runtime-core@3.2.47.f65ce9b3.js";import{k as v,u as f}from"../@vue_reactivity@3.2.47/@vue_reactivity@3.2.47.e3514ec5.js";import{M as g}from"../@vue_shared@3.2.47/@vue_shared@3.2.47.0f451126.js";const h=a=>(p("data-v-fb631367"),a=a(),u(),a),y={class:"copyright"},_=h((()=>m("span",null,"Copyright",-1))),l=h((()=>m("span",{class:"icon"},"©",-1))),d=["href"],j=o({name:"Copyright"}),b=r(o({...j,setup(r){const o=v({copyrightTitle:"GoMaxAiAdmin",copyrightUrl:"/"});t();const p=a();return e((()=>{!async function(){const a=await s.copyright();a.success&&(o.value=a.data)}()})),(a,r)=>(i(),c("footer",y,[_,l,f(p).settings.copyright.beian?(i(),c("a",{key:0,href:f(o).copyrightUrl,target:"_blank",rel:"noopener"},g(f(o).copyrightTitle),9,d)):n("",!0)]))}}),[["__scopeId","data-v-fb631367"]]);export{b as _};
