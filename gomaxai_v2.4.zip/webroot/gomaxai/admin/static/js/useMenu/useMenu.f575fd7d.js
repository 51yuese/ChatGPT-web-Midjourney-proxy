
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{c as s,e as t,r as e}from"../main-43ee7a9a.js";function n(){const n=s(),i=t();return{switchTo:function(s){i.setActived(s),n.settings.menu.switchMainMenuAndPageJump&&e.push(i.sidebarMenusFirstDeepestPath)}}}export{n as u};
