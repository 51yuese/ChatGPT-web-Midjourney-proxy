
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
const a=()=>{},s=Array.isArray,o=a=>"function"==typeof a,r=a=>"symbol"==typeof a;export{a as N,o as a,s as b,r as i};
